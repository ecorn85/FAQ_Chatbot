﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;

namespace ChatbotManager.Models
{
    public class Question
    {
        public int id { get; set; }
        public string question { get; set; }
        public bool isActive { get; set; }
        public int frequencyInSec { get; set; }
        public BigInteger timestamp { get; set; }
        public string reply { get; set; }
        public List<List<string>> keyPhraseSets { get; set; }
    }

}
