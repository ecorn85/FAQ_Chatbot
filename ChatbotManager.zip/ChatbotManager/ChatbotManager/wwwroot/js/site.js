﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

function toggleCollapse(headId, btnId){
    var btnClasses = document.getElementById(btnId).classList;
    var headStyle = document.getElementById(headId).style;
    if (btnClasses.contains("fa-chevron-down")) {
        btnClasses.remove("fa-chevron-down");
        btnClasses.add("fa-chevron-up");
        headStyle.borderRadius = "10px 10px 0px 0px";
    }
    else if (btnClasses.contains("fa-chevron-up")) {
        btnClasses.remove("fa-chevron-up");
        btnClasses.add("fa-chevron-down");
        headStyle.borderRadius = "10px";
    }
}