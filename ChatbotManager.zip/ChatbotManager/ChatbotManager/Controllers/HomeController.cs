﻿using System;
using System.Collections.Generic;
using System.Web;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ChatbotManager.Models;
using Newtonsoft.Json.Linq;
using System.Numerics;

namespace ChatbotManager.Controllers
{
    public class HomeController : Controller
    {

        public JObject FAQJ = JObject.Parse(System.IO.File.ReadAllText("..\\..\\Shared_Resources\\FAQ.json"));
        public List<Question> questions;
        public IActionResult Index()
        {
            questions = readJSON();
            ViewData["Channel"] = (string)FAQJ["channel"];
            
            return View(questions);
        }

        public IActionResult Edit(int id = -1)
        {
            questions = readJSON();
            Question q;
            if(id == -1)
            {
                q = new Question();
            }
            else
            {
                q = questions[id];
            }
            return View(q);
        }


        public IActionResult Delete(int id)
        {
            questions = readJSON();
            try
            {
                questions.Remove(questions[id]);
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine("Id: " + id + " " + e);
            }
            return Index();
        }


        private bool updateJSON()
        {
            return false;
        }
        private bool writeToFile()
        {
            try
            {

                return true;
            }
            catch
            {
                return false;
            }
            
        }

        private List<Question> readJSON()
        {
            return FAQJ["questions"].ToObject<List<Question>>();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
